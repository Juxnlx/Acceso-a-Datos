package com.example.alumnos_api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/alumnos")
public class AlumnoController {
    
    @Autowired
    private AlumnoRepository repo;
    
    // 1. LISTAR TODOS LOS ALUMNOS (GET)
    @GetMapping
    public List<Alumno> listar() {
        return repo.findAll();
    }
    
    // 2. CREAR ALUMNO (POST)
    @PostMapping
    public Alumno crear(@Valid @RequestBody Alumno alumno) {
        return repo.save(alumno);
    }
    
    // 3. ACTUALIZAR ALUMNO (PUT)
    @PutMapping("/{id}")
    public ResponseEntity<Alumno> actualizar(@PathVariable Long id, @Valid @RequestBody Alumno alumno) {
        Optional<Alumno> alumnoExistente = repo.findById(id);
        if (alumnoExistente.isPresent()) {
            Alumno a = alumnoExistente.get();
            a.setNombre(alumno.getNombre());
            a.setEmail(alumno.getEmail());
            return ResponseEntity.ok(repo.save(a));
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    // 4. ELIMINAR ALUMNO (DELETE)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    // 5. BUSCAR ALUMNO POR ID (GET)
    @GetMapping("/{id}")
    public ResponseEntity<Alumno> buscarPorId(@PathVariable Long id) {
        Optional<Alumno> alumno = repo.findById(id);
        if (alumno.isPresent()) {
            return ResponseEntity.ok(alumno.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    // 6. BUSCAR POR NOMBRE (OPCIONAL - usa el query method)
    @GetMapping("/buscar")
    public List<Alumno> buscarPorNombre(@RequestParam String nombre) {
        return repo.findByNombre(nombre);
    }
}